// import 'package:dartz/dartz.dart';
// import 'package:flutter_riverpod/flutter_riverpod.dart';

// import '../../../../core/failure/failure.dart';

// final applicationLocalRepoProvider = Provider<IApplicationRepository>((ref) {
//   return ApplicationLocalRepositoryImpl(
//     jobLocalDataSource: ref.read(applicationLocalDataSourceProvider),
//   );
// });

// class ApplicationLocalRepositoryImpl implements IApplicationRepository {
//   final ApplicationLocalDataSource applicationLocalDataSource;

//   ApplicationLocalRepositoryImpl({
//     required this.applicationLocalDataSource,
//   });


//   @override
//   Future<Either<Failure, bool>> deleteJob(String id) {
//     // TODO: implement removeBookmark
//     throw UnimplementedError();
//   }

// }
