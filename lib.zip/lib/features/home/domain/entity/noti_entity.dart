class NotiEntity {
  final String? id;

  final String noti;

  NotiEntity({
    this.id,
    required this.noti,
  });
}
