class ChangePasswordEntity {
  final String pw;
  final String cpw;
  final String currentPw;

  ChangePasswordEntity(
      {required this.pw, required this.cpw, required this.currentPw});
}
