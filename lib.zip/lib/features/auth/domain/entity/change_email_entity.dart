class ChangeEmailEntity {
  final String email;
  final String confirmEmail;

  ChangeEmailEntity({required this.email, required this.confirmEmail});
}
